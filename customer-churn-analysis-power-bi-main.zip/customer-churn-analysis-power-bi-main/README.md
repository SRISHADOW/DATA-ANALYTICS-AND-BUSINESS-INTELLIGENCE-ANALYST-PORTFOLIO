# Analyzing Customer Churn in Power BI

## My Solution

 In this Power BI case study, I'll investigate a dataset from an example telecom company called Databel and analyze their churn rates.
 This case study helps to understand why customers are churning at the rate they are, and how to reduce churn.
 
 Overview page:
 
 ![obrazek](https://user-images.githubusercontent.com/90547920/209800612-deff3e4b-8b4d-405b-98bd-013fc1ccaeb6.png)
